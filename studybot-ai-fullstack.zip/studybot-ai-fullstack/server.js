require("dotenv").config();

const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const MODES = new Set(["explain", "summarize", "quiz", "solve"]);
const SUBJECTS = new Set(["General", "Python", "Mathematics", "Electronics", "Physics"]);
const LEVELS = new Set(["Beginner", "Intermediate", "Advanced"]);

function demoReply({ mode, subject, level, message }) {
  const topic = String(message || "").trim();
  if (!topic) return "Type a topic or question and I’ll help you study it.";

  if (mode === "summarize") {
    return `## Summary\n\nHere are concise study notes for **${topic}** (${subject}, ${level} level):\n\n- **Main idea:** Identify the central concept and what it is used for.\n- **Key points:** Break the topic into its important terms, rules, and steps.\n- **Remember:** Connect each definition to one example.\n- **Revision tip:** Explain the idea in your own words, then test yourself without looking at your notes.\n\n> Demo mode is active. Add an API key in your `.env` file for AI-generated summaries tailored to your notes.`;
  }

  if (mode === "quiz") {
    return `## Quick practice quiz: ${topic}\n\n**1. Which option best describes the main idea of ${topic}?**\n- A. A relevant definition or principle\n- B. An unrelated concept\n- C. A random value\n- D. None of these\n\n**2. What should you do first when applying this concept?**\n- A. Check the question and identify the known information\n- B. Skip the given information\n- C. Guess immediately\n- D. Ignore units\n\n**3. Why are examples useful when learning ${topic}?**\n- A. They show how a concept is applied\n- B. They replace understanding\n- C. They remove the need to practise\n- D. They are always identical\n\n**4. Which is a good way to check your understanding?**\n- A. Explain it in your own words\n- B. Memorize only the title\n- C. Avoid questions\n- D. Skip revision\n\n**5. If your answer is incorrect, what should you do?**\n- A. Review the reasoning and try again\n- B. Stop learning the topic\n- C. Ignore the mistake\n- D. Change the question\n\n**Demo answer guide:** 1-A, 2-A, 3-A, 4-A, 5-A.\n\n*Add an API key to generate topic-specific questions and explanations.*`;
  }

  if (mode === "solve") {
    return `## Step-by-step approach\n\nLet’s work through **${topic}** at the ${level.toLowerCase()} level:\n\n1. **Understand the question.** Write down exactly what needs to be found or explained.\n2. **List the given information.** Include values, definitions, and any constraints.\n3. **Choose the relevant concept.** Identify the formula, rule, or method that applies.\n4. **Work carefully.** Substitute values or apply each logical step in order.\n5. **Check the result.** Verify the units, assumptions, and whether the answer makes sense.\n\n*This is a general demo framework. Add an API key for a worked solution specific to your question.*`;
  }

  return `## ${topic}\n\n**In simple terms:** ${topic} is the concept you’re exploring in ${subject}. To understand it, start with its definition, learn why it is useful, and then connect it to a small example.\n\n### How to study it\n1. Learn the key definition.\n2. Identify the main rule or steps.\n3. Work through one example.\n4. Try a practice question without looking at the explanation.\n\n### Check your understanding\nCan you explain the idea in two or three sentences and give one example?\n\n*Demo mode is active. Add an API key in `.env` to enable tailored AI answers.*`;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, mode: process.env.OPENAI_API_KEY ? "ai" : "demo" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [], mode = "explain", subject = "General", level = "Beginner" } = req.body || {};

    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "Please enter a question or some notes." });
    }
    if (!MODES.has(mode) || !SUBJECTS.has(subject) || !LEVELS.has(level)) {
      return res.status(400).json({ error: "Invalid study settings. Please refresh and try again." });
    }

    const safeHistory = Array.isArray(history)
      ? history.slice(-10).filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
          .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }))
      : [];

    if (!process.env.OPENAI_API_KEY) {
      return res.json({ reply: demoReply({ message, mode, subject, level }), mode: "demo" });
    }

    const modeInstructions = {
      explain: "Explain the topic clearly with a definition, intuition, and a simple example.",
      summarize: "Summarize the user's supplied notes into well-organized, accurate revision notes. Preserve important facts.",
      quiz: "Create exactly 5 multiple-choice questions with 4 options each. Put the answer key and brief explanations at the end.",
      solve: "Solve the user's problem step by step. Explain why each step is taken and check the final result."
    };

    const systemPrompt = `You are StudyBot AI, a patient and encouraging study assistant.
Subject: ${subject}. Student level: ${level}.
Study mode: ${mode}. Instructions: ${modeInstructions[mode]}
Use clear headings and readable Markdown. Adapt the explanation to the student's level.
For educational questions, show reasoning in a helpful, concise way. If the question is ambiguous, state the assumption or ask a clarifying question.
Do not claim to have accessed files, websites, or school materials unless provided in the conversation.`;

    const messages = [
      { role: "system", content: systemPrompt },
      ...safeHistory,
      { role: "user", content: message.trim().slice(0, 12000) }
    ];

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages,
        temperature: 0.5
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("AI provider error:", response.status, data.error?.message || "Unknown error");
      return res.status(502).json({
        error: "The AI service could not answer right now. Check your API key/model and try again."
      });
    }

    const reply = data.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: "The AI service returned an empty response." });

    res.json({ reply, mode: "ai" });
  } catch (error) {
    console.error("Chat endpoint error:", error);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`StudyBot AI running at http://localhost:${PORT}`);
});