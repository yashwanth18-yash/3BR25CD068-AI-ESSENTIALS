const state = {
  subject: "General",
  level: "Beginner",
  mode: "explain",
  history: [],
  busy: false
};

const modeNames = {
  explain: "Explain Topic",
  summarize: "Summarize Notes",
  quiz: "Generate Quiz",
  solve: "Problem-Solving Steps"
};

const placeholders = {
  explain: "Ask me anything...",
  summarize: "Paste your notes here and I’ll summarize them...",
  quiz: "What topic should the quiz cover?",
  solve: "Paste a problem you want to solve step by step..."
};

const $ = (selector) => document.querySelector(selector);
const messagesEl = $("#messages");
const welcomeEl = $("#welcome");
const inputEl = $("#message-input");
const sendButton = $("#send-button");

function updateSettingsUI() {
  $("#crumb-mode").textContent = modeNames[state.mode];
  $("#top-level").textContent = state.level;
  $("#mode-hint").innerHTML = `<span class="hint-spark">✦</span> ${modeNames[state.mode]} <span class="hint-dot">·</span> ${state.subject} <span class="hint-dot">·</span> ${state.level}`;
  inputEl.placeholder = placeholders[state.mode];

  document.querySelectorAll("[data-subject]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.subject === state.subject));
  document.querySelectorAll("[data-level]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.level === state.level));
  document.querySelectorAll("[data-mode]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.mode === state.mode));
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}

// A small Markdown renderer for AI text; HTML is escaped before formatting.
function renderMarkdown(text) {
  let safe = escapeHTML(text);
  safe = safe.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
  safe = safe.replace(/^### (.*)$/gm, "<h3>$1</h3>");
  safe = safe.replace(/^## (.*)$/gm, "<h2>$1</h2>");
  safe = safe.replace(/^# (.*)$/gm, "<h2>$1</h2>");
  safe = safe.replace(/^\s*>\s?(.*)$/gm, "<blockquote>$1</blockquote>");
  safe = safe.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  safe = safe.replace(/\*(.*?)\*/g, "<em>$1</em>");
  safe = safe.replace(/`([^`]+)`/g, "<code>$1</code>");

  const lines = safe.split("\n");
  let output = "";
  let listType = null;
  const closeList = () => {
    if (listType) output += listType === "ul" ? "</ul>" : "</ol>";
    listType = null;
  };
  for (const line of lines) {
    const unordered = line.match(/^\s*[-•]\s+(.*)$/);
    const ordered = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (unordered || ordered) {
      const type = unordered ? "ul" : "ol";
      if (listType !== type) { closeList(); output += type === "ul" ? "<ul>" : "<ol>"; listType = type; }
      output += `<li>${(unordered || ordered)[1]}</li>`;
    } else {
      closeList();
      if (line.trim()) {
        if (/^<(h2|h3|blockquote|pre|ul|ol)/.test(line.trim())) output += line;
        else output += `<p>${line}</p>`;
      }
    }
  }
  closeList();
  return output;
}

function addMessage(role, content, isTyping = false) {
  welcomeEl.hidden = true;
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "assistant" ? "✦" : "You";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (isTyping) {
    bubble.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
    row.id = "typing-message";
  } else if (role === "assistant") {
    bubble.innerHTML = renderMarkdown(content);
  } else {
    bubble.textContent = content;
  }
  row.append(avatar, bubble);
  messagesEl.appendChild(row);
  $("#chat-area").scrollTop = $("#chat-area").scrollHeight;
  row.scrollIntoView({ behavior: "smooth", block: "nearest" });
  return row;
}

function resizeInput() {
  inputEl.style.height = "auto";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 160) + "px";
}

async function sendMessage(prefill) {
  if (state.busy) return;
  const message = (typeof prefill === "string" ? prefill : inputEl.value).trim();
  if (!message) { inputEl.focus(); return; }

  inputEl.value = "";
  resizeInput();
  state.busy = true;
  sendButton.disabled = true;
  addMessage("user", message);
  const typing = addMessage("assistant", "", true);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        history: state.history,
        mode: state.mode,
        subject: state.subject,
        level: state.level
      })
    });
    const data = await response.json();
    typing.remove();

    if (!response.ok) throw new Error(data.error || "Unable to get a response.");
    addMessage("assistant", data.reply);
    state.history.push({ role: "user", content: message });
    state.history.push({ role: "assistant", content: data.reply });
    state.history = state.history.slice(-10);
    $("#connection-label").textContent = data.mode === "ai" ? "AI connected" : "Demo mode · add API key";
  } catch (error) {
    typing.remove();
    addMessage("assistant", `**Something went wrong.**\n\n${error.message}\n\nPlease try again. If you are the project owner, check that the server is running and your API key is configured correctly.`);
  } finally {
    state.busy = false;
    sendButton.disabled = false;
    inputEl.focus();
  }
}

document.querySelectorAll("[data-subject]").forEach(btn => {
  btn.addEventListener("click", () => { state.subject = btn.dataset.subject; updateSettingsUI(); });
});
document.querySelectorAll("[data-level]").forEach(btn => {
  btn.addEventListener("click", () => { state.level = btn.dataset.level; updateSettingsUI(); });
});
document.querySelectorAll("[data-mode]").forEach(btn => {
  btn.addEventListener("click", () => { state.mode = btn.dataset.mode; updateSettingsUI(); inputEl.focus(); });
});
document.querySelectorAll("[data-prompt]").forEach(btn => {
  btn.addEventListener("click", () => sendMessage(btn.dataset.prompt));
});

$("#chat-form").addEventListener("submit", event => {
  event.preventDefault();
  sendMessage();
});
inputEl.addEventListener("input", resizeInput);
inputEl.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});
$("#clear-button").addEventListener("click", () => {
  state.history = [];
  messagesEl.innerHTML = "";
  welcomeEl.hidden = false;
  inputEl.value = "";
  resizeInput();
  inputEl.focus();
});
$("#menu-button").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
document.addEventListener("click", event => {
  if (window.innerWidth <= 680 &&
      !event.target.closest("#sidebar") &&
      !event.target.closest("#menu-button")) {
    $("#sidebar").classList.remove("open");
  }
});

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    $("#connection-label").textContent = data.mode === "ai" ? "AI connected" : "Demo mode · add API key";
  } catch {
    $("#connection-label").textContent = "Waiting for server";
  }
}
updateSettingsUI();
checkHealth();